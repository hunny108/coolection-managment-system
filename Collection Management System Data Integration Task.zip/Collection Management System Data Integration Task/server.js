import express from 'express';
import * as http from 'http';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import dotenv from 'dotenv';
import Redis from 'ioredis';
import bodyParser from 'body-parser'
dotenv.config();

import db from './database/index.js';
import caseRoute from './routes/caseRoute.js';

const app = express();

app.use(express.json());
app.use(bodyParser.json())
app.use(express.urlencoded({ extended: true }));
app.use(helmet());
app.use(cors());
app.use(morgan('dev'));

app.get('/', (req, res) => {
  res.send('Basic Express Server with Sequelize is running!');
});

app.use('/api', caseRoute);
app.use((err, req, res, next) => {
  console.error('Global Error:', err);
  res.status(500).json(null);
});

app.use((req, res, next) => {
  res.status(404).json(null);
});

const redis = new Redis({
  host: process.env.REDIS_HOST,
  port: process.env.REDIS_PORT,
});

redis.on('connect', () => {
  console.log('Connected to Redis successfully!');
});

const PORT = process.env.PORT || 3000;

(async () => {
  try {
    await db.sequelize.authenticate();
    console.log('Database connected successfully!');

    await db.sequelize.sync({ alter: true });
    console.log('Database & tables generated!');

    const server = http.createServer(app);
    server.listen(PORT, () => {
      console.log(`Server is listening on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to connect to the database:', error);
  }
})();
