'use strict';

const casesBank = (sequelize, DataTypes) => {
	const casesBank = sequelize.define('casesBank', {
		id: {
			type: DataTypes.UUID,
			primaryKey: true,
			defaultValue: DataTypes.UUIDV4,
			allowNull: false,
		},
		bank_name: DataTypes.STRING,
		property_name: {
			type: DataTypes.STRING,
		},
		city: DataTypes.STRING,
		borrower_name: DataTypes.STRING,
	});

	return casesBank;
};
export default casesBank
