import fs from 'fs';
import path from 'path';
import { Sequelize, DataTypes } from 'sequelize';
import { dbConfig } from '../dbconfig.js';

const sequelize = process.env.DB_URL
    ? new Sequelize(process.env.DB_URL)
    : new Sequelize(dbConfig.db_name, dbConfig.db_user_name, dbConfig.db_password, {
        host: dbConfig.db_host,
        port: dbConfig.db_port,
        dialect: dbConfig.db_dialect || 'postgres',
        logging: false,
        define: {
            freezeTableName: false,
            underscored: true,
            timestamps: true,
        },
        pool: {
            max: dbConfig.db_pool.max,
            min: dbConfig.db_pool.min,
            acquire: dbConfig.db_pool.acquire,
            idle: dbConfig.db_pool.idle,
        },
    });

const db = {};

const modelFiles = fs.readdirSync(path.join(process.cwd(), 'database/models'))
    .filter((file) => file.endsWith('.js') && file !== 'index.js');

for (const file of modelFiles) {
    const model = (await import(path.join(process.cwd(), 'database/models', file))).default(sequelize, DataTypes);
    console.log('model :', model.name);
    db[model.name] = model;
}

Object.keys(db).forEach((modelName) => {
    if (db[modelName].associate) {
        db[modelName].associate(db);
    }
});

db.sequelize = sequelize;
db.Sequelize = Sequelize;

export default db;
