import Joi from 'joi';
import caseServices from '../services/case.js';
import cron from 'node-cron';
const { listCases, fetchCSVFilesFromDrive, processCSVFiles, processCSV } = caseServices;


export class caseController {

    async listCase(req, res, next) {
        const validateSchema = {
            start_date: Joi.string().optional(),  //"start_date": "2023-10-01"
            end_date: Joi.string().optional(),
        };
        try {
            const validateBody = await Joi.validate(req.query, validateSchema);
            const result = await listCases(validateBody);
            return res.status(200).json(result);

        } catch (error) {
            console.log('error:', error);
            return next(error);
        }
    }
}

export default new caseController();



cron.schedule('0 10,17 * * *', async () => {
    try {
        console.log('Running importCSVData for testing...');

        const files = await fetchCSVFilesFromDrive();
        if (files.length === 0) {
            console.log('No CSV files found in the folder.');
            return;
        }

        const downloadedResults = await processCSVFiles(files);
        console.log('downloadedResults :', downloadedResults);
        if (downloadedResults.length === 0) {
            console.log('Error in downloading or processing files.');
            return;
        }

        const allImportedData = [];
        for (const file of downloadedResults) {
            const results = await processCSV(file);
            console.log('results :', results);
        }

    } catch (error) {
        console.error('Error during initial data import:', error);
    }
});
