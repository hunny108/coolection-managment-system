
import db from '../database/index.js';
import { Op } from 'sequelize';
import { google } from 'googleapis';
import csvParser from 'csv-parser';
import { createWriteStream } from 'fs';
import path from 'path';
import fs from 'fs';
import casesBankQueue from '../helper/queue.js';
import checkAndDeleteFile from "../helper/deleteFile.js"

const { casesBank } = db;
const SCOPES = ['https://www.googleapis.com/auth/drive.readonly', 'https://www.googleapis.com/auth/drive'];
const KEY_FILE = path.resolve('serviceAccount.json');
const FOLDER_ID = '1Dzs-5WuVkzOmogFOGcOXG3tD0ovatiRj';
const auth = new google.auth.GoogleAuth({
    keyFile: KEY_FILE,
    scopes: SCOPES,
});

const caseServices = {

    async fetchCSVFilesFromDrive() {
        try {
            const drive = google.drive({ version: 'v3', auth });
            const response = await drive.files.list({
                q: `'${FOLDER_ID}' in parents and trashed=false`,
                fields: 'files(id, name)',
            });

            const files = response.data.files;
            if (!files.length) {
                console.log('No CSV files found in the folder.');
                return [];
            }
            return files;
        } catch (error) {
            console.error('Error fetching CSV files:', error);
            throw error;
        }
    },

    async processCSVFiles(files) {
        const downloadedFiles = [];

        for (const file of files) {
            const filePath = path.resolve(file.name);
            const dest = createWriteStream(filePath);
            const fileId = file.id;
            const drive = google.drive({ version: 'v3', auth });

            try {
                const res = await drive.files.export({
                    fileId: fileId,
                    mimeType: 'text/csv',
                }, { responseType: 'stream' });

                await new Promise((resolve, reject) => {
                    res.data
                        .on('end', () => {
                            console.log(`Downloaded ${file.name}`);
                            downloadedFiles.push(filePath);
                            resolve();
                        })
                        .on('error', err => {
                            console.error('Error downloading file:', err);
                            reject(err);
                        })
                        .pipe(dest);
                });
            } catch (error) {
                console.error(`Error processing file ${file.name}:`, error);
            }
        }

        return downloadedFiles;
    },

    async processCSV(fileName) {
        const chunkSize = 100;
        let results = [];
        let isFirstRow = true;

        return new Promise((resolve, reject) => {
            fs.createReadStream(fileName)
                .pipe(csvParser({ headers: false }))
                .on('data', async (data) => {
                    if (isFirstRow) {
                        isFirstRow = false;
                        return;
                    }

                    const newData = {
                        bank_name: data[0],
                        property_name: data[1],
                        city: data[2],
                        borrower_name: data[3]
                    };

                    results.push(newData);

                    if (results.length >= chunkSize) {
                        await casesBankQueue.add({ chunk: results });
                        results = [];
                    }
                })
                .on('end', async () => {
                    console.log(' end:',);
                    if (results.length > 0) {
                        await casesBankQueue.add({ chunk: results });
                    }
                    console.log(`Finished processing CSV: ${fileName}`);

                    //await checkAndDeleteFile(fileName)
                    resolve();
                })
                .on('error', (err) => {
                    console.error('Error processing CSV:', err);
                    reject(err);
                });
        });
    },


    async listCases(validateBody) {
        const { start_date, end_date } = validateBody;

        let whereCondition = {};

        if (start_date && end_date) {
            whereCondition.created_at = {
                [Op.between]: [new Date(start_date), new Date(end_date)]
            };
        }
        console.log('whereCondition :', whereCondition);

        return await casesBank.findAll({
            where: whereCondition
        });
    }
};

export default caseServices;
