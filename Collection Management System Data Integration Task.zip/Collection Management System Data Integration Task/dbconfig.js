import dotenv from 'dotenv';
dotenv.config();
const env = process.env;
export const dbConfig = {
    db_host: env.DB_HOST,
    db_user_name: env.DB_USER_NAME,
    db_password: env.DB_PASSWORD,
    db_name: env.DB_NAME,
    db_dialect: env.DB_DIALECT,
    db_pool: {
        max: 20,
        min: 0,
        acquire: 0,
        idle: 0,
    },
    db_port: env.DB_PORT
};