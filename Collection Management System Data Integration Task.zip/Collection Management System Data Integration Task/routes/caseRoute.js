import Express from 'express';
import controller from '../controllers/case.js';

export default Express
	.Router()
	.get('/case', controller.listCase)