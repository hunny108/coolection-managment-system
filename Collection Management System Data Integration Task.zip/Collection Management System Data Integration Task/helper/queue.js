import Bull from 'bull';
import db from '../database/index.js';
import validateData from './dataValidator.js';
import logger from '../helper/logger.js';

const casesBankQueue = new Bull('casesBankQueue', {
    redis: {
        host: process.env.REDIS_HOST,
        port: process.env.REDIS_PORT
    },
});

casesBankQueue.process(async (job) => {
    const { chunk } = job.data;
    const { casesBank } = db;

    const uniqueRecordsSet = new Set();
    let uniqueRecords = [];

    try {
        const validationErrors = await Promise.all(chunk.map(validateData));
        const errors = validationErrors.flat().filter(error => error.length > 0);

        if (errors.length > 0) {
            logger.error(`Validation errors: ${JSON.stringify(errors)}`);
            console.log(`Validation errors: ${errors.join(', ')}`);
            return;
        }

        for (let record of chunk) {
            const recordKey = `${record.bank_name}-${record.property_name}-${record.city}-${record.borrower_name}`;

            if (!uniqueRecordsSet.has(recordKey)) {
                let isDuplicate = await casesBank.findOne({
                    where: {
                        bank_name: record.bank_name,
                        property_name: record.property_name,
                        city: record.city,
                        borrower_name: record.borrower_name
                    }
                });

                if (!isDuplicate) {
                    uniqueRecords.push(record);
                    uniqueRecordsSet.add(recordKey);
                }
            }
        }
        if (uniqueRecords.length > 0) {
            await casesBank.bulkCreate(uniqueRecords);
            logger.info(`Processed ${uniqueRecords.length} unique records.`);
        } else {
            logger.info('No unique records to insert.');
        }

    } catch (error) {
        logger.error(`Error processing records: ${error.message}`);
    }
});

export default casesBankQueue;
