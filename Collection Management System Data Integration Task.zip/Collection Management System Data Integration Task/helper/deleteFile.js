import fs from 'fs/promises';

async function checkAndDeleteFile(fileName) {
    try {
        await fs.access(fileName);
        await fs.unlink(fileName);
        console.log(`Deleted ${fileName}`);
    } catch (err) {
        console.error('Error deleting the file or file does not exist:', err.message);
    }
}
export default checkAndDeleteFile;