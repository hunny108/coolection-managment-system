export default async function validateData(record) {
console.log('record :', record);
    const errors = [];

    if (!record.bank_name || typeof record.bank_name !== 'string' || record.bank_name.trim() === '') {
        errors.push('Bank name is required and must be a non-empty string.');
    }
    if (!record.property_name || typeof record.property_name !== 'string' || record.property_name.trim() === '') {
        errors.push('Property name is required and must be a non-empty string.');
    }
    if (!record.city || typeof record.city !== 'string' || record.city.trim() === '') {
        errors.push('City is required and must be a non-empty string.');
    }
    if (!record.borrower_name || typeof record.borrower_name !== 'string' || record.borrower_name.trim() === '') {
        errors.push('Borrower name is required and must be a non-empty string.');
    }

    return errors;
}